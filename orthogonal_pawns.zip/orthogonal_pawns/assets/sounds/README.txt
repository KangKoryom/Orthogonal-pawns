Place three sound files here before building:
  move.wav     - played on a normal (non-capture) move
  capture.wav  - played when a pawn is captured
  win.wav      - played when a game ends

These were not supplied with the spec. The app already handles a missing
file gracefully (it catches the playback error silently, per the spec),
so the game runs fine without them - you just won't hear sound effects
until you add your own .wav files here.
