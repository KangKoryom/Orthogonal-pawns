# Orthogonal Pawns 5x5 - 12 vs 12

A checkers-style abstract board game, Flutter/Material 3, built from the
provided spec. Moves are **orthogonal only** (Up/Down/Left/Right) - no
diagonals, ever.

## Run it

```bash
flutter pub get
flutter run
```

## Build a release APK

```bash
flutter build apk --release
```

## What's implemented

- 5x5 board, 24 pawns (12 White / 12 Black), empty center at (2,2), exactly
  matching the spec's setup (`board[0]` = bottom row / White back rank,
  `board[4]` = top row / Black back rank; rendered top-to-bottom on screen).
- Normal orthogonal moves and jump-capture moves, per the spec's formal rules.
- **Mandatory Capture** toggle: when on, a player with any capture available
  anywhere on the board may only capture - selecting a pawn with no capture
  of its own shows zero legal moves.
- **Chain captures**: after a capture, if the same pawn can capture again
  from its new square, the player (or AI) must continue with that pawn in
  the same turn. Normal moves are blocked during a chain even if Mandatory
  Capture is off, since the chain rule takes precedence.
- **Win conditions**: opponent has 0 pawns, or opponent has 0 legal moves.
  Optional draw at 30 moves without a capture.
- **Undo**: a full history stack (board, turn, capture counts) pushed once
  per completed turn - not on intermediate chain steps. Disabled mid-chain
  and while the AI is "thinking."
- **Reset**: restores the starting position and clears history/scores-for-
  the-session state (win totals persist - see below).
- **Score persistence**: `whiteWins` / `blackWins` are saved with
  `shared_preferences` and reloaded on launch.
- **Sound**: `audioplayers` plays `move.wav` / `capture.wav` / `win.wav`
  from `assets/sounds/`. Missing files are caught and ignored silently, so
  the game works even before you drop in real audio (see
  `assets/sounds/README.txt`).
- **AI (Black, when "vs AI" is on)**: picks a legal move; if captures are
  available it takes one, preferring the capture with the greatest chain
  potential (estimated by simulating ahead); otherwise picks the first
  available normal move. ~350ms delay between AI moves for a natural pace,
  including through its own chains.
- **UI**: wood-textured squares (`#D7CCC8` / `#8D6E63`), walnut gradient
  board frame, circular gradient W/B pawns, yellow selection highlight,
  green border + dot for legal normal-move squares, red border + X for
  legal capture squares, top bar with both switches plus Undo/Reset, and a
  bottom score panel (wins and captures for both sides).

## Project layout

```
lib/main.dart          - entire app (single file, per spec)
pubspec.yaml            - dependencies: audioplayers, shared_preferences
assets/sounds/          - drop move.wav / capture.wav / win.wav here
```

## Notes on the spec's acceptance tests

- Test 1 (12/12/1-empty start), Test 2 (edge pawn can't move off-board),
  Test 3 (basic capture geometry), Test 4 (mandatory capture filters
  normal moves), Test 5 (chain capture forces continuation, turn doesn't
  switch mid-chain), and Test 6 (undo restores a captured pawn and the
  capture count) are all satisfied by the rules engine (`getAllMoves`,
  `getCapturesFrom`, `applyMove`, and the undo history stack) - these are
  plain functions separate from the UI, so they're straightforward to
  unit-test with `flutter_test` if you want automated coverage later.
